1	Emma's Birthday	Birthday party at home	2024-11-10	2024-11-10	Family	2024-10-26 19:31:33.933244
2	Doctor Appointment	Annual checkup	2024-11-15	2024-11-15	Family	2024-10-26 19:31:33.933244
3	School Meeting	Parent council	2024-11-20	2024-11-20	School	2024-10-26 19:31:33.933244
4	Work Presentation	Quarterly review	2024-11-25	2024-11-25	Work	2024-10-26 19:31:33.933244
5	Family Dinner	Grandparents visiting	2024-12-01	2024-12-01	Family	2024-10-26 19:31:33.933244
6	Breakfast: Chicken Stir Fry	Quick and healthy stir fry	2024-10-26	2024-10-26	Meal	2024-10-26 20:05:35.929958
7	Breakfast: yum	yum yum 	2024-10-26	2024-10-26	Meal	2024-10-26 20:17:53.412327
8	home 		2024-10-27	\N	Academic	2024-10-27 00:18:37.65709
