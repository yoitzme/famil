1	Spaghetti Bolognese	Classic Italian pasta dish	4	45	2024-10-26 19:49:32.99418	\N
2	Chicken Stir Fry	Quick and healthy stir fry	3	30	2024-10-26 19:49:32.99418	\N
3	Vegetable Soup	Hearty vegetable soup	6	60	2024-10-26 19:49:32.99418	\N
4	yum	yum yum 	4	30	2024-10-26 20:17:33.768441	\N
5	FANFG	RUM	4	30	2024-10-27 22:33:01.54899	2 SEC
6	gummy	guumy gum	4	30	2024-10-28 00:06:28.211614	cook gum
